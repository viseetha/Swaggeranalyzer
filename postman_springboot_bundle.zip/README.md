
# Postman Generator Tool (Spring Boot + Maven)

This tool reads an OpenAPI 3.0 spec and generates a chained Postman collection where one endpoint's output maps into the input of the next.

## How to Run

1. Build the project:
```bash
mvn clean install
```

2. Run the Spring Boot app:
```bash
mvn spring-boot:run
```

3. Hit the endpoint:
```
POST http://localhost:8080/generate?openApiPath=/path/to/openapi.yaml
```

## Features

- Parses OpenAPI spec (including body, path, query params)
- Detects field dependencies across endpoints
- Generates Postman JSON with chained variable usage

## TODO

- Add dependency resolution logic
- Add Postman JSON file writer
