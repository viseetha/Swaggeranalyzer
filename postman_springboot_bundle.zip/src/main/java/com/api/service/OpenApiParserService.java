
package com.api.service;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.parser.OpenAPIV3Parser;
import org.springframework.stereotype.Service;
import java.io.File;

@Service
public class OpenApiParserService {

    public OpenAPI parseOpenApi(String filePath) {
        return new OpenAPIV3Parser().read(filePath);
    }
}
