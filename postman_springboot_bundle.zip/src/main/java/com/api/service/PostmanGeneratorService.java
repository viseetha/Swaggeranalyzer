
package com.api.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.PathItem;
import io.swagger.v3.oas.models.media.Schema;
import io.swagger.v3.oas.models.parameters.Parameter;
import io.swagger.v3.oas.models.Operation;
import io.swagger.v3.oas.models.media.MediaType;
import io.swagger.v3.oas.models.media.Content;
import io.swagger.v3.oas.models.media.RequestBody;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileWriter;
import java.util.*;

@Service
public class PostmanGeneratorService {

    static class PostmanCollection {
        public Info info = new Info();
        public List<Item> item = new ArrayList<>();
    }

    static class Info {
        public String name = "Generated Collection";
        public String schema = "https://schema.getpostman.com/json/collection/v2.1.0/collection.json";
    }

    static class Item {
        public String name;
        public Request request = new Request();
    }

    static class Request {
        public String method;
        public Url url = new Url();
        public Body body = new Body();
    }

    static class Url {
        public String raw;
        public String host = "localhost";
        public List<String> path = new ArrayList<>();
        public List<Query> query = new ArrayList<>();
    }

    static class Query {
        public String key;
        public String value;
    }

    static class Body {
        public String mode = "raw";
        public String raw;
    }

    public void generateChainedCollection(OpenAPI openAPI) {
        PostmanCollection collection = new PostmanCollection();

        openAPI.getPaths().forEach((path, pathItem) -> {
            for (PathItem.HttpMethod method : pathItem.readOperationsMap().keySet()) {
                Operation operation = pathItem.readOperationsMap().get(method);
                Item item = new Item();
                item.name = operation.getSummary() != null ? operation.getSummary() : path;
                item.request.method = method.name();
                item.request.url.raw = "http://localhost:8080" + path;

                for (String segment : path.split("/")) {
                    if (!segment.isEmpty()) item.request.url.path.add(segment);
                }

                if (operation.getParameters() != null) {
                    for (Parameter parameter : operation.getParameters()) {
                        Query q = new Query();
                        q.key = parameter.getName();
                        q.value = "{{" + parameter.getName() + "}}";
                        item.request.url.query.add(q);
                    }
                }

                RequestBody requestBody = operation.getRequestBody();
                if (requestBody != null && requestBody.getContent() != null) {
                    Content content = requestBody.getContent();
                    MediaType mediaType = content.get("application/json");
                    if (mediaType != null && mediaType.getSchema() != null) {
                        String bodyStr = generateSampleJson(mediaType.getSchema(), openAPI.getComponents().getSchemas());
                        item.request.body.raw = bodyStr;
                    }
                }

                collection.item.add(item);
            }
        });

        try {
            ObjectMapper mapper = new ObjectMapper();
            FileWriter writer = new FileWriter(new File("generated_postman_collection.json"));
            mapper.writerWithDefaultPrettyPrinter().writeValue(writer, collection);
            System.out.println("Postman collection saved to generated_postman_collection.json");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String generateSampleJson(Schema<?> schema, Map<String, Schema> allSchemas) {
        if (schema.get$ref() != null) {
            String ref = schema.get$ref().replace("#/components/schemas/", "");
            schema = allSchemas.get(ref);
        }

        Map<String, Object> sample = new LinkedHashMap<>();
        if (schema.getProperties() != null) {
            for (Object key : schema.getProperties().keySet()) {
                Schema<?> propSchema = (Schema<?>) schema.getProperties().get(key);
                sample.put(key.toString(), "{{" + key.toString() + "}}");
            }
        }

        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(sample);
        } catch (Exception e) {
            return "{}";
        }
    }
}
