
package com.api.controller;

import com.api.service.OpenApiParserService;
import com.api.service.PostmanGeneratorService;
import io.swagger.v3.oas.models.OpenAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/generate")
public class GeneratorController {

    @Autowired
    OpenApiParserService parserService;

    @Autowired
    PostmanGeneratorService generatorService;

    @PostMapping
    public String generateFromSpec(@RequestParam String openApiPath) {
        OpenAPI openAPI = parserService.parseOpenApi(openApiPath);
        generatorService.generateChainedCollection(openAPI);
        return "Postman collection generated (check output directory)";
    }
}
