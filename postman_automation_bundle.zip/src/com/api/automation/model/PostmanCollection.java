
package com.api.automation.model;

import java.util.*;

public class PostmanCollection {
    public Info info;
    public List<Item> item = new ArrayList<>();

    public static class Info {
        public String name = "Chained API Collection";
        public String schema = "https://schema.getpostman.com/json/collection/v2.1.0/collection.json";
    }

    public static class Item {
        public String name;
        public Request request;
        public List<Event> event = new ArrayList<>();
    }

    public static class Event {
        public String listen = "test";
        public Script script;
    }

    public static class Script {
        public String type = "text/javascript";
        public List<String> exec;
    }

    public static class Request {
        public String method;
        public Url url;
        public Body body;
        public Map<String, String> header = new HashMap<>();
    }

    public static class Url {
        public String raw;
        public String host;
        public String path;
        public List<QueryParam> query;
    }

    public static class QueryParam {
        public String key;
        public String value;
    }

    public static class Body {
        public String mode = "raw";
        public String raw;
    }
}
